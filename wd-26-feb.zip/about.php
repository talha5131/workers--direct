 <?php include("header.php"); ?>
    <!-- Top Scroll End -->
    <!-- Top Header Wrapper Start -->
   
	  <!-- jp Tittle Wrapper Start -->
    <div class="jp_tittle_main_wrapper">
        <div class="jp_tittle_img_overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="jp_tittle_heading_wrapper">
                        <div class="jp_tittle_heading">
                            <h2>About-Us</h2>
                        </div>
                        <div class="jp_tittle_breadcrumb_main_wrapper">
                            <div class="jp_tittle_breadcrumb_wrapper">
                                <ul>
                                    <li><a href="#">Home</a> <i class="fa fa-angle-right"></i></li>
                                    
                                    <li>About-Us</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- jp Tittle Wrapper End -->
	<!-- aboutus_section start-->
    <div class="aboutus_section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-xs-12 col-sm-12  margin-bottom-20">
                    <div class="about_text_wrapper">
                        <div class="section_heading section_2_heading">
                            <h2>Welcome <span>To workers Direct</span></h2>
                        </div>
                        <p>Workers Direct specialised in temporary & short term staff recruitment. As one of the best Recruitment Agency London we provide temp & perm warehouse, catering staff across UK.</p>
                        <p>ABOUT WORKERS DIRECT ?
Workers Direct specialised in temporary & short term staff recruitment. As one of the best Recruitment Agency London we provide temp & perm warehouse, catering staff across UK.

Workers Direct are experts in recruitment with over a decade of experience in finding the best solution for our companies and candidates. Our temporary staff recruitment team work with employers and staff, both local to our site and across the UK, in order to match the right person to the right role. Our quick-response consultants are highly professional and knowledgeable. As one of the leading temping agency London We are committed to finding the answer for your recruitment needs, and cover a wide range of recruitment services from temporary, peak season or long-term work, including contract.</p>
                       
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-xs-12 col-sm-12 margin-bottom-20">
                    <div class="about_image_wrapper">
                        <img class="img-responsive" src="images/content/about-workers-direct-1.jpg" alt="about-img">
                    </div>
                </div>
                 
                <div class="col-lg-9 col-md-9 col-xs-12 col-sm-12">
                     <div class="about_text_wrapper abt_2_para">
                       <div class="section_heading section_2_heading">
                            <h2>why we<span> do it ?</span></h2>
                        </div>
                        <p class="margin-bottom-20">Workers Direct specialise in providing all kind of temporary & short terms staff across the UK. As one of the leading and cost effective temping agency, we have long list of satisfied clientele that includes Hospitals, Care homes, Charities, Hotels, country clubs, caterers, National & Internationals businesses and local schools. We find roles for office workers, administrators, kitchen staff, construction labourers, factory workers, warehouse team members, and teaching staff, as well as support workers in many other fields.</p>
                        
                        <div class="section_heading section_2_heading">
                            <h4> Temporary <span> Staffing Solution</span></h4>
                        </div>
                        <p class="margin-bottom-20"> Workers Direct is the authority when it comes to <a href="#"> temporary staffing</a>. We recruit for temporary, temp-to-perm and short-term roles across a range of specialisations and are dedicated to getting it right. We are as flexible as your needs, with workers that can fill a gap in any workforce from very next day.</p>
                        <div class="section_heading section_2_heading">
                            <h4> Recruitment <span> Solution</span></h4>
                        </div>
                        <p class="margin-bottom-20">
                        Our team will save your time, the stress of looking for an employee, as we can dedicate our entire time to the search perfect candidate. Rely on Workers Direct as a focused partner and we will guarantee to find a timely answer to your request. Our team find out and note each candidate’s ability and personality, and match workers to the company that will best suit their needs, skills. We are the recruitment solutions that make sense.
                        </p>
                        <div class="section_heading section_2_heading">
                            <h4>Agency Workers  <span> & Job Placement </span></h4>
                        </div>
                        <p class="margin-bottom-20">
                        We are experts in job placement, with thousands of candidates placed in roles over the last 10 years. Our workers represent our agency, and therefore we have tough criteria and high standards for them to match – that they bring to your company. The <a href="#"> temporary workers we provide are adaptable and professionals</a>, our attention to detail over each placement means that the worker comes with right skills and very flexible according to client’s requirements.
                        </p>
                        <div class="section_heading section_2_heading">
                            <h4> <span> Outsourcing </span></h4>
                        </div>
                        <p class="margin-bottom-20">
                        By outsourcing your recruitment search, we take the stress and hassle out of your already complicated work life. By saving your time, the trouble, cost of advertising, interviewing and hiring. We oversee the entire process and give you the 100% result. We also have connections with universities, Job centres, Employment agencies, job boards and professional bodies that provide us with newly trained staff and graduates, meaning that Workers Direct has a <a href="#"> Database of Millions of temporary staff</a> that can help you.
                        </p>
                        <div class="section_heading section_2_heading">
                            <h4>CRB <span>  / DBS Check </span></h4>
                        </div>
                        <p class="margin-bottom-20">
                        With a decade’s experience in matching teaching and support staff to businesses including schools, we know that it is vital to find an honest worker – and we understand the weight of responsibility that all of those roles entail. All employees are CRB/DBS checked, as standard. We organise the process, guiding candidates through the application and supporting them, and meaning that there is no cost or worry for an employer.
                        </p>
                        <div class="section_heading section_2_heading">
                            <h4>Reference  <span>Check  </span></h4>
                        </div>
                        <p class="margin-bottom-20">
                           Nothing is more frustrating, when recruiting, than finding a staff member has made a fraudulent claim on their CV or application. We vet and check all candidates, including contacting references – so that you can be assured that the experienced worker you receive is what you expect.  This guarantee also means that our candidates go to businesses that know that they will receive the best – offering them a better opportunity for professional development.
                        </p>
                        <div class="section_heading section_2_heading">
                            <h4> Job  <span> Advertisement </span></h4>
                        </div>
                        <p class="margin-bottom-50">
                           With varied sources on hand with which to advertise your vacancy, and the know-how to get it out there, Workers Direct get you the best quality workers. We advertise roles on our site and through the use of social media, as well as through traditional & latest methods, with our team matching candidates that come in every day to the roles that they know we have. We are champions for your business, putting applicant to advertisement and then into jobs quickly and aptly.
                        </p>
          
                   
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 margin-top-60">
                    <div class="jp_first_right_sidebar_main_wrapper">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="jp_add_resume_wrapper">
                                    <div class="jp_add_resume_img_overlay"></div>
                                    <div class="jp_add_resume_cont">
                                        <img src="images/content/resume_logo.png" alt="logo" />
                                        <h4>Get Best Matched Jobs On your Email. Add Resume NOW!</h4>
                                        <ul>
                                            <li><a href="#"><i class="fa fa-plus-circle"></i> &nbsp;ADD RESUME</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="jp_spotlight_main_wrapper">
                                    <div class="spotlight_header_wrapper">
                                        <h4>Job Spotlight</h4>
                                    </div>
                                    <div class="jp_spotlight_slider_wrapper">
                                        <div class="owl-carousel owl-theme">
                                            <div class="item">
                                                <div class="jp_spotlight_slider_img_Wrapper">
                                                    <img src="images/content/spotlight_img.jpg" alt="spotlight_img" />
                                                </div>
                                                <div class="jp_spotlight_slider_cont_Wrapper">
                                                    <h4>HTML Developer (1 - 2 Yrs Exp.)</h4>
                                                    <p>Webstrot Technology Ltd.</p>
                                                    <ul>
                                                        <li><i class="fa fa-cc-paypal"></i>&nbsp; $12K - 15k P.A.</li>
                                                        <li><i class="fa fa-map-marker"></i>&nbsp; Caliphonia, PO 455001</li>
                                                    </ul>
                                                </div>
                                                <div class="jp_spotlight_slider_btn_wrapper">
                                                    <div class="jp_spotlight_slider_btn">
                                                        <ul>
                                                            <li><a href="#"><i class="fa fa-plus-circle"></i> &nbsp;ADD RESUME</a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="item">
                                                <div class="jp_spotlight_slider_img_Wrapper">
                                                    <img src="images/content/spotlight_img.jpg" alt="spotlight_img" />
                                                </div>
                                                <div class="jp_spotlight_slider_cont_Wrapper">
                                                    <h4>HTML Developer (1 - 2 Yrs Exp.)</h4>
                                                    <p>Webstrot Technology Ltd.</p>
                                                    <ul>
                                                        <li><i class="fa fa-cc-paypal"></i>&nbsp; $12K - 15k P.A.</li>
                                                        <li><i class="fa fa-map-marker"></i>&nbsp; Caliphonia, PO 455001</li>
                                                    </ul>
                                                </div>
                                                <div class="jp_spotlight_slider_btn_wrapper">
                                                    <div class="jp_spotlight_slider_btn">
                                                        <ul>
                                                            <li><a href="#"><i class="fa fa-plus-circle"></i> &nbsp;ADD RESUME</a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="item">
                                                <div class="jp_spotlight_slider_img_Wrapper">
                                                    <img src="images/content/spotlight_img.jpg" alt="spotlight_img" />
                                                </div>
                                                <div class="jp_spotlight_slider_cont_Wrapper">
                                                    <h4>HTML Developer (1 - 2 Yrs Exp.)</h4>
                                                    <p>Webstrot Technology Ltd.</p>
                                                    <ul>
                                                        <li><i class="fa fa-cc-paypal"></i>&nbsp; $12K - 15k P.A.</li>
                                                        <li><i class="fa fa-map-marker"></i>&nbsp; Caliphonia, PO 455001</li>
                                                    </ul>
                                                </div>
                                                <div class="jp_spotlight_slider_btn_wrapper">
                                                    <div class="jp_spotlight_slider_btn">
                                                        <ul>
                                                            <li><a href="#"><i class="fa fa-plus-circle"></i> &nbsp;ADD RESUME</a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="jp_rightside_job_categories_wrapper">
                                    <div class="jp_rightside_job_categories_heading">
                                        <h4>Jobs by Category</h4>
                                    </div>
                                    <div class="jp_rightside_job_categories_content">
                                        <ul>
                                            <li><i class="fa fa-caret-right"></i> <a href="#">Graphic Designer <span>(214)</span></a></li>
                                            <li><i class="fa fa-caret-right"></i> <a href="#">Engineering Jobs <span>(514)</span></a></li>
                                            <li><i class="fa fa-caret-right"></i> <a href="#">Mainframe Jobs <span>(554)</span></a></li>
                                            <li><i class="fa fa-caret-right"></i> <a href="#">Legal Jobs <span>(457)</span></a></li>
                                            <li><i class="fa fa-caret-right"></i> <a href="#">IT Jobs <span>(1254)</span></a></li>
                                            <li><i class="fa fa-caret-right"></i> <a href="#">R&D Jobs <span>(554)</span></a></li>
                                            <li><i class="fa fa-caret-right"></i> <a href="#">Government Jobs <span>(350)</span></a></li>
                                            <li><i class="fa fa-caret-right"></i> <a href="#">PSU Jobs <span>(221)</span></a></li>
                                            <li><i class="fa fa-plus-circle"></i> <a href="#">View All Categories</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                             
                             
                        </div>
                    </div>
                </div>

                 
                <!-- <div class="col-lg-4 col-md-4 col-xs-12 col-sm-12 margin-bottom-20"> -->
               
                <!-- </div> -->
                 
            </div>
        </div>
    </div>
	<!-- jp best deal Wrapper Start -->
    <div class="jp_best_deal_main_wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="jp_best_deal_heading_wrapper">
                        <div class="jp_best_deal_heading">
                            <h4>How We Work</h4>
                            <br>
                            <p>Our Step By Step Staffing Process</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="jp_best_deal_main_cont_wrapper jp_best_deal_main_cont_wrapper2">
                        <div class="jp_best_deal_icon_sec">
                            <i class="flaticon-wallet"></i>
                        </div>
                        <div class="jp_best_deal_cont_sec">
                            <h4><a href="#">SUBMIT A JOB</a></h4>
                            <p> SUBMIT A JOB Online via website or mobile application with all the relevant information / job description.</p>
                            <ul class=" margin-top-20">
                     <li><i class="green fa fa-plus-circle"></i> <a class="green">&nbsp; READ MORE</a></li>
                   </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="jp_best_deal_main_cont_wrapper">
                        <div class="jp_best_deal_icon_sec">
                            <i class="flaticon-magnifying-glass"></i>
                        </div>
                        <div class="jp_best_deal_cont_sec">
                            <h4><a href="#">Discover</a></h4>
                            <p> Our professional recruiter will contact you within no time to find out your hiring needs, <span id="dots" style="display: inline;"> </span><span id="more" style="display: none;">skills and experience of an ideal candidate & finally the job duration and location.</p>
                            
                   <ul class=" margin-top-20">
                     <li><i class="green fa fa-plus-circle"></i> <a onclick="myFunction()" id="myBtn" >&nbsp;READ MORE</a></li>
                   </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="jp_best_deal_main_cont_wrapper">
                        <div class="jp_best_deal_icon_sec">
                            <i class="flaticon-users"></i>
                        </div>
                        <div class="jp_best_deal_cont_sec">
                            <h4><a href="#">Recruit</a></h4>
                            <p>Our team of professional recruitment consultant create EJO & Submitted to various talent resources.</p>
                            <ul class=" margin-top-20">
                     <li><i class="green fa fa-plus-circle"></i> <a class="green">&nbsp; READ MORE</a></li>
                   </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="jp_best_deal_main_cont_wrapper jp_best_deal_main_cont_wrapper2">
                        <div class="jp_best_deal_icon_sec">
                            <i class="flaticon-shield"></i>
                        </div>
                        <div class="jp_best_deal_cont_sec">
                            <h4><a href="#">Prescreen</a></h4>
                            <p>We will make sure the selected candidate is 100% screened through multiple interviews and <span id="dots-1" style="display: inline;"> </span><span id="more-1" style="display: none;">background / reference check.</p>
                     <ul class=" margin-top-20">
                        <li><i class="green fa fa-plus-circle"></i> <a onclick="myFunctionOne()" id="myBtn-1" >&nbsp;READ MORE</a></li>
                    </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="jp_best_deal_main_cont_wrapper jp_best_deal_main_cont_wrapper2">
                        <div class="jp_best_deal_icon_sec">
                            <i class="flaticon-notification"></i>
                        </div>
                        <div class="jp_best_deal_cont_sec">
                            <h4><a href="#">Hire</a></h4>
                            <p>Hire reliable and flexible temp / temp to perm staff according to client requirements and place<span id="dots-2" style="display: inline;"> </span><span id="more-2" style="display: none;"> them on job location on short notice.</p>
                    <ul class=" margin-top-20">
                        <li><i class="green fa fa-plus-circle"></i> <a onclick="myFunctionTwo()" id="myBtn-2" >&nbsp;READ MORE</a></li>
                    </ul>    
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="jp_best_deal_main_cont_wrapper jp_best_deal_main_cont_wrapper2">
                        <div class="jp_best_deal_icon_sec">
                            <i class="flaticon-award"></i>
                        </div>
                        <div class="jp_best_deal_cont_sec">
                            <h4><a href="#">Our Guarentee</a></h4>
                            <p>We promise to our clients and candidates that we are &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>
                            <div>  <span id="dots-3" style="display: inline;"> </span><span id="more-3" style="display: none;">  
                        <ul>
                            <li><i class="green fa fa-check-square" aria-hidden="true"></i>  &nbsp;&nbsp; Bespoke in Our Services   </li>
                            <li><i class="green fa fa-check-square" aria-hidden="true"></i>  &nbsp;&nbsp;Determined in Our Approach  
                            </li>
                            <li><i class="green fa fa-check-square" aria-hidden="true"></i>  &nbsp;&nbsp;Quick response to Your Needs and Requests   </li>
                            <li><i class="green fa fa-check-square" aria-hidden="true"></i>  &nbsp;&nbsp;Reliable and Trustworthy in Providing the 100% Results   </li>
                            <li><i class="green fa fa-check-square" aria-hidden="true"></i>  &nbsp;&nbsp; Cost effective in all our all short terms and Temporary Staffing Placement  </li>
                          
                             
                        </ul>   
</div>
                        <ul class=" margin-top-20">
                        <li><i class="green fa fa-plus-circle"></i> <a onclick="myFunctionThree()" id="myBtn-3">&nbsp;READ MORE</a></li>
                    </ul>  
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <!-- jp best deal Wrapper End -->
    <!-- jp career Wrapper Start -->
    <div class="jp_career_main_wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="jp_hiring_slider_main_wrapper">
                        <div class="jp_career_slider_heading_wrapper">
                            <h2>Career advice</h2>
                        </div>
                        <div class="jp_career_slider_wrapper">
                            <div class="owl-carousel owl-theme">
                                <div class="item jp_recent_main">
                                    <div class="jp_career_main_box_wrapper">
                                        <div class="jp_career_img_wrapper">
                                            <img src="images/content/car_img1.jpg" alt="career_img" />
                                        </div>
                                        <div class="jp_career_cont_wrapper">
                                            <p><i class="fa fa-calendar"></i>&nbsp;&nbsp; <a href="#">20 OCT, 2017</a></p>
                                            <h3><a href="#">Hey Seeker, It’s Time</a></h3>
                                            <p>Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat.</p>
                                        </div>
                                    </div>
                                    <div class="jp_career_slider_bottom_cont">
                                        <ul>
                                            <li><img src="images/content/blog_small_img.jpg" alt="small_img" class="img-circle">&nbsp;&nbsp; <a href="#">Jhon Doe</a></li>
                                        </ul>
                                        <p><a href="#"><i class="fa fa-comments"></i></a></p>
                                    </div>
                                </div>
                                <div class="item jp_recent_main">
                                    <div class="jp_career_main_box_wrapper">
                                        <div class="jp_career_img_wrapper">
                                            <img src="images/content/car_img2.jpg" alt="career_img" />
                                        </div>
                                        <div class="jp_career_cont_wrapper">
                                            <p><i class="fa fa-calendar"></i>&nbsp;&nbsp; <a href="#">20 OCT, 2017</a></p>
                                            <h3><a href="#">Hey Seeker, It’s Time</a></h3>
                                            <p>Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat.</p>
                                        </div>
                                    </div>
                                    <div class="jp_career_slider_bottom_cont">
                                        <ul>
                                            <li><img src="images/content/blog_small_img.jpg" alt="small_img" class="img-circle">&nbsp;&nbsp; <a href="#">Jhon Doe</a></li>
                                        </ul>
                                        <p><a href="#"><i class="fa fa-comments"></i></a></p>
                                    </div>
                                </div>
                                <div class="item jp_recent_main">
                                    <div class="jp_career_main_box_wrapper">
                                        <div class="jp_career_img_wrapper">
                                            <img src="images/content/car_img3.jpg" alt="career_img" />
                                        </div>
                                        <div class="jp_career_cont_wrapper">
                                            <p><i class="fa fa-calendar"></i>&nbsp;&nbsp; <a href="#">20 OCT, 2017</a></p>
                                            <h3><a href="#">Hey Seeker, It’s Time</a></h3>
                                            <p>Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat.</p>
                                        </div>
                                    </div>
                                    <div class="jp_career_slider_bottom_cont">
                                        <ul>
                                            <li><img src="images/content/blog_small_img.jpg" alt="small_img" class="img-circle">&nbsp;&nbsp; <a href="#">Jhon Doe</a></li>
                                        </ul>
                                        <p><a href="#"><i class="fa fa-comments"></i></a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- jp career Wrapper End -->
    <!-- jp counter Wrapper Start -->
    <div class="jp_counter_main_wrapper">
        <div class="gc_counter_cont_wrapper">
            <div class="count-description">
                <span class="timer">2540</span><i class="fa fa-plus"></i>
                <h5 class="con1">Jobs Available</h5>
            </div>
        </div>
        <div class="gc_counter_cont_wrapper2">
            <div class="count-description">
                <span class="timer">7325</span><i class="fa fa-plus"></i>
                <h5 class="con2">Members</h5>
            </div>
        </div>
        <div class="gc_counter_cont_wrapper3">
            <div class="count-description">
                <span class="timer">1924</span><i class="fa fa-plus"></i>
                <h5 class="con3">Resumes</h5>
            </div>
        </div>
        <div class="gc_counter_cont_wrapper4">
            <div class="count-description">
                <span class="timer">4275</span><i class="fa fa-plus"></i>
                <h5 class="con4">Company</h5>
            </div>
        </div>
    </div>
    <!-- jp counter Wrapper End -->
    <!-- aboutus_section end -->
    <div class="aboutus_page_2_section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-xs-12 col-sm-12">
                    <div class="aboutus_text_section abt_txt_page_2">
                        <h2>How We <span>Work</span></h2>
                        <p>We do not depend always on technology for candidate searches, preferring to use experience, industry acumen and intuition to identify what each individual could bring to a specific business. This intelligent & human approach pays surpluses time after time. We recognise the trust clients make in Workers Direct and our priority is always to make sure we attain the best results for all concerned.</p>
                        <div class="row">
                            <div class="col-md-6">
                                <ul>
                                    <li><i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>&nbsp;&nbsp;Audit &amp; Assurance</li>
                                    <li><i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>&nbsp;&nbsp;Business Services</li>
                                    <li><i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>&nbsp;&nbsp;IT Control Solutions</li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <ul>
                                    <li><i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>&nbsp;&nbsp;Audit &amp; Assurance</li>
                                    <li><i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>&nbsp;&nbsp;Business Services</li>
                                    <li><i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i>&nbsp;&nbsp;IT Control Solutions</li>
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="col-lg-6 col-md-6 col-xs-12 col-sm-12">
                    <div class="accordion_wrapper abt_page_2_wrapper">
                        <div class="panel-group" id="accordion_threeLeft">
                            <div class="panel panel-default">
                                <div class="panel-heading desktop">
                                    <h4 class="panel-title">
                                        <a class="collapsed" data-toggle="collapse" data-parent="#accordion_threeLeft" href="#collapseTwentyLeftone" aria-expanded="true">
                                  Our Visions and Missions
                              </a>
                                    </h4>
                                </div>
                                <div id="collapseTwentyLeftone" class="panel-collapse collapse" aria-expanded="true" role="tablist">
                                    <div class="panel-body">
                                        Praesent in nisl egestas mauris aliquam luctus. Ut auctor faucibus orci, nec semper purus ultrices idorbi nec lorem risus orbi vitae felis gravida Pellentesque id eros quis massa convallis feugiat eu quis urna.
                                    </div>
                                </div>
                            </div>
                            <!-- /.panel-default -->
                            <div class="panel panel-default">
                                <div class="panel-heading horn">
                                    <h4 class="panel-title">
                                        <a data-toggle="collapse" data-parent="#accordion_threeLeft" href="#collapseTwentyLeftTwo" aria-expanded="false">
                                 Our Corporate Responsibility
                              </a>
                                    </h4>
                                </div>
                                <div id="collapseTwentyLeftTwo" class="panel-collapse collapse in" aria-expanded="false" role="tablist">
                                    <div class="panel-body">
                                        Praesent in nisl egestas mauris aliquam luctus. Ut auctor faucibus orci, nec semper purus ultrices idorbi nec lorem risus orbi vitae felis gravida Pellentesque id eros quis massa convallis feugiat eu quis urna.
                                    </div>
                                </div>
                            </div>
                            <!-- /.panel-default -->
                            <div class="panel panel-default">
                                <div class="panel-heading bell">
                                    <h4 class="panel-title">
                                        <a class="collapsed" data-toggle="collapse" data-parent="#accordion_threeLeft" href="#collapseTwentyLeftThree" aria-expanded="false">
                                Visual Page Builder
                              </a>
                                    </h4>
                                </div>
                                <div id="collapseTwentyLeftThree" class="panel-collapse collapse" aria-expanded="false" role="tablist">
                                    <div class="panel-body">
                                        Praesent in nisl egestas mauris aliquam luctus. Ut auctor faucibus orci, nec semper purus ultrices idorbi nec lorem risus orbi vitae felis gravida Pellentesque id eros quis massa convallis feugiat eu quis urna.
                                    </div>
                                </div>
                            </div>
                            <!-- /.panel-default -->
                        </div>
                        <!--end of /.panel-group-->
                    </div>
                </div>
                <!--end of /.col-sm-6-->
            </div>
        </div>
    </div>
    <!--end of /.col-sm-6-->
	<!-- jp downlord Wrapper Start -->
    <div class="jp_downlord_main_wrapper">
        <div class="jp_downlord_img_overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 hidden-sm hidden-xs">
                    <div class="jp_down_mob_img_wrapper">
                        <img src="images/content/mobail.png" alt="mobail_img" />
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="ss_download_wrapper_details">
                        <h1><span>Download</span><br>Job Portal App Now!</h1>
                        <p>Fast, Simple & Delightful. All it takes is 30 seconds to Download.</p>
                        
                        <a href="https://play.google.com/store/apps/details?id=com.mst_developers.workers_direct&hl=en" class="ss_playstore"><span><i class="fa fa-android" aria-hidden="true"></i></span> Play Store</a>
                        

                        
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 visible-sm visible-xs">
                    <div class="jp_down_mob_img_wrapper">
                        <img src="images/content/mobail.png" class="img-responsive" alt="mobail_img" />
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- jp downlord Wrapper End -->
    <?php include("footer.php"); ?>