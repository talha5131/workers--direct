<!-- jp Newsletter Wrapper Start -->
<div class="jp_main_footer_img_wrapper">
        <div class="jp_newsletter_img_overlay_wrapper"></div>
        <div class="jp_newsletter_wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                        <div class="jp_newsletter_text">
                            <img src="images/content/news_logo.png" class="img-responsive" alt="news_logo" />
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                        <div class="jp_newsletter_field">
                            <i class="fa fa-envelope-o"></i>
                            <input type="text" placeholder="Enter Your Email">
                            <button type="submit">Submit</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- jp Newsletter Wrapper End -->

        <!-- jp footer Wrapper Start -->
        <div class="jp_footer_main_wrapper">
            <div class="container">
                <div class="row">
                     
                    <div class="jp_footer_three_sec_main_wrapper">
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="jp_footer_first_cont_wrapper">
                                <div class="jp_footer_first_cont">
                                    <h2>Who We Are</h2>
                                    <p>Workers Direct specialised in temporary & short term staff recruitment. As one of the best Recruitment Agency London we provide temp & perm warehouse, catering staff across UK.   <span id="dots-7" style="display: inline;"> </span><span id="more-7" style="display: none;">  Workers Direct are experts in recruitment with over a decade of experience in finding the best solution for our companies and candidates. </span></p> 
                                         
                                  <ul>
                                  <li><i class="green fa fa-plus-circle"></i> <a onclick="myFunctionSeven()"        id="myBtn-7">&nbsp;READ MORE</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="jp_footer_candidate_wrapper jp_footer_candidate_wrapper2">
                                <div class="jp_footer_candidate">
                                    <h2>Useful Links</h2>
                                    <ul>
                                        <li><a href="about.php"><i class="fa fa-caret-right" aria-hidden="true"></i> About Us</a></li>
                                        <li><a href="terms-conditions.php"><i class="fa fa-caret-right" aria-hidden="true"></i> Terms & Conditions</a></li>
                                        <li><a href="privacy-policy.php"><i class="fa fa-caret-right" aria-hidden="true"></i> Privacy Policy</a></li>
                                        <li><a href="#"><i class="fa fa-caret-right" aria-hidden="true"></i> Careers with Us</a></li>
                                       
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="jp_footer_candidate_wrapper jp_footer_candidate_wrapper3">
                                <div class="jp_footer_candidate">
                                    <h2>Our Partners</h2>
                                    <ul>
                                        <li><a href="https://staff-direct.co.uk"><i class="fa fa-caret-right" aria-hidden="true"></i> Staff Direct</a></li>
                                        <li><a href="https://recruitment-agency.london"><i class="fa fa-caret-right" aria-hidden="true"></i> Recruitment Agency London</a></li>
                                        <li><a href="https://labourer.agency"><i class="fa fa-caret-right" aria-hidden="true"></i> Labourer Agency</a></li>
                                        <li><a href="https://temping-agency.com"><i class="fa fa-caret-right" aria-hidden="true"></i> Temping Agency</a></li>
                                       
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                            <div class="jp_footer_candidate_wrapper jp_footer_candidate_wrapper4">
                                <div class="jp_footer_candidate">
                                    <h2>Information</h2>
                                    <ul>
                                       
                                        <li><a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i>344-48 High Road, Ilford, IG1 1QP</a></li>
                                        <li><a href="mailto: info@workers-direct.com"><i class="fa fa-envelope" aria-hidden="true"></i> info@workers-direct.com</a></li>
                                        <li><a href="tel: 02030869080"><i class="fa fa-phone" aria-hidden="true"></i>  0 203 086 90 80</a></li>
                                       
                                        
                                         
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="jp_bottom_footer_Wrapper">
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <div class="jp_bottom_footer_left_cont">
                                        <p>© 2020 Workers Direct. All Rights Reserved.</p>
                                    </div>
                                    <div class="jp_bottom_top_scrollbar_wrapper">
                                        <a href="javascript:" id="return-to-top"><i class="fa fa-angle-up"></i></a>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <div class="jp_bottom_footer_right_cont">
                                        <ul>
                                            <li><a href="https://www.facebook.com/workersdirect"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="https://twitter.com/workersdirect"><i class="fa fa-twitter"></i></a></li>
                                            <li><a href="https://www.linkedin.com/in/workers/"><i class="fa fa-linkedin"></i></a></li>
                                            <li><a href="https://plus.google.com/u/0/+WorkersdirectUK/posts"><i class="fa fa-google-plus"></i></a></li>
                                            <li class="hidden-xs"><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                                            <li class="hidden-xs"><a href="#"><i class="fa fa-vimeo"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- jp footer Wrapper End -->
	 <!-- chat box Wrapper start -->
	<div id="chat-circle" class="btn btn-raised"> 
		<i class="fa fa-envelope"></i>
	</div>
    <div class="chat-box">
      <div class="chat-box-header">
		ChatBot
        <span class="chat-box-toggle"><i class="fa fa-times"></i></span>
     </div>
    <div class="chat-box-body">
      <div class="chat-box-overlay">   
      </div>
       <div class="chat-logs">
       
       </div><!--chat-log -->
     </div>
     <div class="chat-input">      
      <form>
        <input type="text" id="chat-input" placeholder="Send a message..."/>
       <button type="submit" class="chat-submit" id="chat-submit"><i class="fa fa-paper-plane" ></i></button>
       </form>      
      </div>
   </div>
  <!-- chat box Wrapper end -->
    <!--main js file start-->
    <script src="js/jquery_min.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/jquery.menu-aim.js"></script>
    <script src="js/jquery.countTo.js"></script>
    <script src="js/jquery.inview.min.js"></script>
    <script src="js/owl.carousel.js"></script>
    <script src="js/modernizr.js"></script>
    <script src="js/jquery.magnific-popup.js"></script>
    <script src="js/custom_II.js"></script>
    <script src="js/hs.megamenu.js"></script>
    <!--main js file end-->

    <script>
        function initMap() {
        	var uluru = {lat: -36.742775, lng:  174.731559};
        	var map = new google.maps.Map(document.getElementById('map'), {
        	zoom: 15,
        	scrollwheel: false,
        	center: uluru
        	});
        	var marker = new google.maps.Marker({
        	position: uluru,
        	map: map
        	});
        	}
    </script>
    
    <script>
        // Magnific popup-video//
        	$('.popup-youtube').magnificPopup({
                disableOn: 700,
                type: 'iframe',
                mainClass: 'mfp-fade',
                removalDelay: 160,
                preloader: false,
        
                fixedContentPos: false
            });
    </script>

    <!-- Read More JS -->
    <script type="text/javascript">
			function myFunction() {
			var dots = document.getElementById("dots");
			var moreText = document.getElementById("more");
			var btnText = document.getElementById("myBtn");
			if (dots.style.display === "none") {
			dots.style.display = "inline";
			btnText.innerHTML = "READ MORE";
			moreText.style.display = "none";
			} else {
			dots.style.display = "none";
			btnText.innerHTML = "READ LESS";
			moreText.style.display = "inline";
			}
			}
			function myFunctionOne() {
			var dots = document.getElementById("dots-1");
			var moreText = document.getElementById("more-1");
			var btnText = document.getElementById("myBtn-1");
			if (dots.style.display === "none") {
			dots.style.display = "inline";
			btnText.innerHTML = "READ MORE";
			moreText.style.display = "none";
			} else {
			dots.style.display = "none";
			btnText.innerHTML = "READ LESS";
			moreText.style.display = "inline";
			}
			}
			function myFunctionTwo() {
			var dots = document.getElementById("dots-2");
			var moreText = document.getElementById("more-2");
			var btnText = document.getElementById("myBtn-2");
			if (dots.style.display === "none") {
			dots.style.display = "inline";
			btnText.innerHTML = "READ MORE";
			moreText.style.display = "none";
			} else {
			dots.style.display = "none";
			btnText.innerHTML = "READ LESS";
			moreText.style.display = "inline";
			}
			}
			
					function myFunctionThree() {
			var dots = document.getElementById("dots-3");
			var moreText = document.getElementById("more-3");
			var btnText = document.getElementById("myBtn-3");
			if (dots.style.display === "none") {
			dots.style.display = "inline";
			btnText.innerHTML = "READ MORE";
			moreText.style.display = "none";
			} else {
			dots.style.display = "none";
			btnText.innerHTML = "READ LESS";
			moreText.style.display = "inline";
			}
			}
			function myFunctionFour() {
			var dots = document.getElementById("dots-4");
			var moreText = document.getElementById("more-4");
			var btnText = document.getElementById("myBtn-4");
			if (dots.style.display === "none") {
			dots.style.display = "inline";
			btnText.innerHTML = "READ MORE";
			moreText.style.display = "none";
			} else {
			dots.style.display = "none";
			btnText.innerHTML = "READ LESS";
			moreText.style.display = "inline";
			}
			}
			function myFunctionFive() {
			var dots = document.getElementById("dots-5");
			var moreText = document.getElementById("more-5");
			var btnText = document.getElementById("myBtn-5");
			if (dots.style.display === "none") {
			dots.style.display = "inline";
			btnText.innerHTML = "READ MORE";
			moreText.style.display = "none";
			} else {
			dots.style.display = "none";
			btnText.innerHTML = "READ LESS";
			moreText.style.display = "inline";
			}
			}
			function myFunctionSix() {
			var dots = document.getElementById("dots-6");
			var moreText = document.getElementById("more-6");
			var btnText = document.getElementById("myBtn-6");
			if (dots.style.display === "none") {
			dots.style.display = "inline";
			btnText.innerHTML = "READ MORE";
			moreText.style.display = "none";
			} else {
			dots.style.display = "none";
			btnText.innerHTML = "READ LESS";
			moreText.style.display = "inline";
			}
			}
			function myFunctionSeven() {
			var dots = document.getElementById("dots-7");
			var moreText = document.getElementById("more-7");
			var btnText = document.getElementById("myBtn-7");
			if (dots.style.display === "none") {
			dots.style.display = "inline";
			btnText.innerHTML = "READ MORE";
			moreText.style.display = "none";
			} else {
			dots.style.display = "none";
			btnText.innerHTML = "READ LESS";
			moreText.style.display = "inline";
			}
			}
        </script> 
        <!-- Read More Closed -->
   
</body>

</html>